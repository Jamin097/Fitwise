// ActivityCards.js
import React, { useEffect, useState } from 'react';
import { FaBiking, FaRunning, FaWalking } from 'react-icons/fa';
import './styles/ActivityCards.css';

const DEFAULT_ACTIVITIES = [
  { id: 'a1', name: "Bicycle Drill", progress: 45, goal: 36, goalUnit: 'km', currentValue: 17, daysLeft: 2, icon: 'bike' },
  { id: 'a2', name: "Jogging Hero", progress: 13, goal: 12, goalUnit: 'km', currentValue: 2, daysLeft: 17, icon: 'run' },
  { id: 'a3', name: "Healthy Busy", progress: 90, goal: 3600, goalUnit: 'steps', currentValue: 3200, daysLeft: 3, icon: 'walk' },
];

const iconFor = (key) => {
  if (key === 'bike') return <FaBiking />;
  if (key === 'run') return <FaRunning />;
  return <FaWalking />;
};

const storageKey = 'fit_activities_v1';
const searchKey = 'fit_search_query';

const ActivityCards = () => {
  const [activities, setActivities] = useState([]);
  const [editing, setEditing] = useState(null);
  const [editValue, setEditValue] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    // load activities from localStorage or use defaults
    const raw = localStorage.getItem(storageKey);
    const initial = raw ? JSON.parse(raw) : DEFAULT_ACTIVITIES;
    setActivities(initial);
    // load search if any
    const s = localStorage.getItem(searchKey) || '';
    setSearch(s);
  }, []);

  useEffect(() => {
    localStorage.setItem(storageKey, JSON.stringify(activities));
  }, [activities]);

  useEffect(() => {
    localStorage.setItem(searchKey, search);
  }, [search]);

  const increment = (id, amount = 1) => {
    setActivities(prev => prev.map(a => {
      if (a.id !== id) return a;
      const newCurrent = Number(a.currentValue || 0) + amount;
      const pct = Math.min(100, Math.round((newCurrent / a.goal) * 100));
      return { ...a, currentValue: newCurrent, progress: pct };
    }));
  };

  const openEdit = (id) => {
    const a = activities.find(x => x.id === id);
    setEditing(id);
    setEditValue(String(a.currentValue));
  };

  const saveEdit = () => {
    setActivities(prev => prev.map(a => {
      if (a.id !== editing) return a;
      const newCurrent = Number(editValue || 0);
      const pct = Math.min(100, Math.round((newCurrent / a.goal) * 100));
      return { ...a, currentValue: newCurrent, progress: pct };
    }));
    setEditing(null);
    setEditValue('');
  };

  const filtered = activities.filter(a => a.name.toLowerCase().includes(search.trim().toLowerCase()));

  return (
    <div className="activity-cards">
      <div className="activity-controls">
        <input
          type="text"
          placeholder="Search activities..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button onClick={() => { setActivities(DEFAULT_ACTIVITIES); localStorage.removeItem(storageKey); }}>Reset</button>
      </div>

      {filtered.map((activity) => (
        <div className="activity-card" key={activity.id}>
          <div className="activity-header">
            <div className="activity-icon">{iconFor(activity.icon)}</div>
            <div className="activity-name">{activity.name}</div>
          </div>

          <div className="activity-info">
            <div className="activity-details">Goal: {activity.goal} {activity.goalUnit}</div>

            <div className="progress-header">
              <span className="progress-label">Progress</span>
              <span className="progress-percent">{activity.progress}%</span>
            </div>

            <div className="progress-bar">
              <div className="progress" style={{ width: `${activity.progress}%` }}></div>
            </div>

            <div className="current-progress">
              <span>{activity.currentValue}/{activity.goal} {activity.goalUnit}</span>
              <span className="days-left">{activity.daysLeft} days left</span>
            </div>

            <div className="activity-actions">
              <button onClick={() => increment(activity.id, 1)}>+1</button>
              <button onClick={() => increment(activity.id, 5)}>+5</button>
              <button onClick={() => openEdit(activity.id)}>Edit</button>
            </div>

            {editing === activity.id && (
              <div className="edit-row">
                <input
                  type="number"
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                />
                <button onClick={saveEdit}>Save</button>
                <button onClick={() => setEditing(null)}>Cancel</button>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ActivityCards;
