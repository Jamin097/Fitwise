import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./DBManager.css";

export default function DBManager() {
  const navigate = useNavigate();

  const [users, setUsers] = useState([]);
  const [message, setMessage] = useState("");

  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    password: ""
  });

  // -----------------------------
  // LOGOUT
  // -----------------------------
  const logout = () => {
    localStorage.removeItem("isDBManager");
    navigate("/login");
  };

  // -----------------------------
  // FETCH USERS
  // -----------------------------
  const fetchUsers = async () => {
    try {
      const res = await fetch("http://localhost:5000/admin/users");
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      setMessage("❌ Failed to load users");
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // -----------------------------
  // ADD USER
  // -----------------------------
  const addUser = async () => {
    if (!newUser.name || !newUser.email || !newUser.password) {
      setMessage("⚠️ All fields required");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/admin/add-user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newUser)
      });

      const data = await res.json();
      if (!res.ok) {
        setMessage(data.error || "Error adding user");
        return;
      }

      setMessage("✅ User added");
      setNewUser({ name: "", email: "", password: "" });
      fetchUsers();
    } catch {
      setMessage("❌ Server error");
    }
  };

  // -----------------------------
  // DELETE USER
  // -----------------------------
  const deleteUser = async (id) => {
    if (!window.confirm("Delete this user?")) return;

    try {
      await fetch(`http://localhost:5000/admin/delete-user/${id}`, {
        method: "DELETE"
      });
      setMessage("🗑 User deleted");
      fetchUsers();
    } catch {
      setMessage("❌ Delete failed");
    }
  };

  // -----------------------------
  // BACKUP DATABASE (DOWNLOAD TXT)
  // -----------------------------
  const backupDatabase = () => {
    if (users.length === 0) {
      setMessage("⚠️ No users to backup");
      return;
    }

    // Format the users as text
    let fileContent = "DB Backup - Users\n\n";
    users.forEach((u, idx) => {
      fileContent += `User ${idx + 1}\n`;
      fileContent += `ID: ${u.user_id}\n`;
      fileContent += `Name: ${u.name}\n`;
      fileContent += `Email: ${u.email}\n\n`;
    });

    // Create a Blob and trigger download
    const blob = new Blob([fileContent], { type: "text/plain" });
    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = `db_backup_${new Date().toISOString()}.txt`;
    link.click();

    URL.revokeObjectURL(url);
    setMessage("✅ Backup downloaded");
  };

  return (
    <div className="db-manager">
      <div className="db-header">
        <h2>🛠 DB Manager Panel</h2>
        <button className="logout-btn" onClick={logout}>
          Logout
        </button>
      </div>

      {message && <p className="msg" style={{ color: "white" }}>{message}</p>}

      {/* ADD USER */}
      <div className="card">
        <h3>Add User</h3>
        <input
          placeholder="Name"
          value={newUser.name}
          onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
        />
        <input
          placeholder="Email"
          value={newUser.email}
          onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
        />
        <input
          type="password"
          placeholder="Password"
          value={newUser.password}
          onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
        />
        <button onClick={addUser}>Add User</button>
      </div>

      {/* USER LIST */}
      <div className="card">
        <h3>Users</h3>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.user_id}>
                <td>{u.user_id}</td>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>
                  <button
                    className="danger"
                    onClick={() => deleteUser(u.user_id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* BACKUP */}
      <div className="card">
        <h3>Database</h3>
        <button className="backup" onClick={backupDatabase}>
          💾 Backup Database
        </button>
      </div>
    </div>
  );
}
