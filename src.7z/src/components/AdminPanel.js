import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import './AdminPanel.css';

export default function AdminPanel() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [users, setUsers] = useState([]);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const isAdmin = localStorage.getItem("isAdmin");
    if (!isAdmin) navigate("/login");
  }, [navigate]);

  useEffect(() => {
    setLoading(true);
    if (activeTab === "dashboard") {
      setLoading(false);
    } else if (activeTab === "users") {
      fetchUsers();
    } else if (activeTab === "plans") {
      fetchPlans();
    }
  }, [activeTab]);

  const fetchUsers = () => {
    fetch("http://127.0.0.1:5000/admin/users")
      .then(res => res.json())
      .then(data => { setUsers(data); setLoading(false); })
      .catch(() => setLoading(false));
  };

  const fetchPlans = () => {
    fetch("http://127.0.0.1:5000/admin/plans")
      .then(res => res.json())
      .then(data => { setPlans(data); setLoading(false); })
      .catch(() => setLoading(false));
  };

  const deleteUser = (id) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      fetch(`http://127.0.0.1:5000/admin/user/${id}`, { method: "DELETE" })
        .then(() => setUsers(users.filter(u => u.user_id !== id)));
    }
  };

  const deletePlan = (id) => {
    if (window.confirm("Are you sure you want to delete this plan?")) {
      fetch(`http://127.0.0.1:5000/admin/plan/${id}`, { method: "DELETE" })
        .then(() => setPlans(plans.filter(p => p.id !== id)));
    }
  };

  return (
    <div className="admin-panel">
      <header className="admin-header">
        <div className="header-left">
          <h1>Admin Dashboard</h1>
          <p className="subtitle">Manage your fitness platform</p>
        </div>
        <div className="header-right">
          <div className="admin-info">
            <div className="admin-avatar">A</div>
            <span>Admin</span>
          </div>
          <button className="btn-logout" onClick={() => { localStorage.removeItem("isAdmin"); navigate("/login"); }}>
            Logout
          </button>
        </div>
      </header>

      <div className="admin-layout">
        <nav className="admin-sidebar">
          <ul className="sidebar-nav">
            <li><button className={activeTab==="dashboard"?"active":""} onClick={()=>setActiveTab("dashboard")}>📊 Dashboard</button></li>
            <li><button className={activeTab==="users"?"active":""} onClick={()=>setActiveTab("users")}>👥 Users</button></li>
            <li><button className={activeTab==="plans"?"active":""} onClick={()=>setActiveTab("plans")}>📋 Plans</button></li>
          </ul>
        </nav>

        <main className="admin-content">
          {loading && <p className="loading">Loading...</p>}

          {/* Dashboard */}
          {!loading && activeTab==="dashboard" && (
            <div className="admin-dashboard">
              <div className="stats-grid">
                <div className="stat-card"><div className="stat-icon">👥</div><h3>Total Users</h3><div className="stat-number">{users.length}</div></div>
                <div className="stat-card"><div className="stat-icon">📋</div><h3>Total Plans</h3><div className="stat-number">{plans.length}</div></div>
              </div>
            </div>
          )}

          {/* Users */}
          {!loading && activeTab==="users" && (
            <div className="management-section">
              <h2>User Management</h2>
              <div className="table-container">
                <table>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Age</th>
                      <th>Gender</th>
                      <th>Height</th>
                      <th>Weight</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u=>(
                      <tr key={u.user_id}>
                        <td>{u.name}</td>
                        <td>{u.email}</td>
                        <td>{u.age}</td>
                        <td>{u.gender}</td>
                        <td>{u.height_cm}</td>
                        <td>{u.weight_kg}</td>
                        <td>
                          <button className="btn-delete" onClick={()=>deleteUser(u.user_id)}>🗑 Delete</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Plans */}
          {!loading && activeTab==="plans" && (
            <div className="management-section">
              <h2>Plans Management</h2>
              <div className="cards-grid">
                {plans.map(plan => (
                  <div key={plan.id} className="plan-card">
                    <div className="plan-header">
                      <div className="plan-avatar">{plan.name[0]}</div>
                      <div className="plan-info">
                        <h4>{plan.name}</h4>
                        <span className="plan-goal">{plan.goal}</span>
                      </div>
                    </div>
                    <div className="plan-timestamp">Created at: {new Date(plan.created_at).toLocaleString()}</div>
                    <div className="plan-expand">
                      <details>
                        <summary>View Plan</summary>
                        <div className="plan-content">
                          <pre>{JSON.stringify(plan.plan, null, 2)}</pre>
                        </div>
                      </details>
                    </div>
                    <div className="plan-actions">
                      <button className="btn-delete" onClick={() => deletePlan(plan.id)}>🗑 Delete Plan</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
