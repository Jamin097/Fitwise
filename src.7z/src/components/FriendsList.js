// FriendsList.js
import React, { useState } from 'react';
import './styles/FriendsList.css';
import { FaUserFriends, FaAngleRight } from "react-icons/fa";
import Kavya from './Assets/kavya.jpg';
import Bhargav from './Assets/bhargav.jpg';
import Sankar from './Assets/sankar.jpg';
import Chaitu from './Assets/chaitu.jpg';

const FriendsList = () => {
  const friends = [
    { name: "Pheobe Buffay", activity: "Skipping", time: "10 min ago", image: Kavya },
    { name: "Joey Tribbiani", activity: "Slow Jogging", time: "22 min ago", image: Bhargav },
    { name: "Chandler Bing", activity: "Hiking", time: "32 min ago", image: Sankar},
    { name: "Ross Geller", activity: "Quick Sprint", time: "37 min ago", image: Chaitu },
  ];

  const [tab, setTab] = useState('activities');

  return (
    <div className="friends-list">
      <div className="header-section">
        <h2><FaUserFriends /> Friends</h2>
        <button className="view-all-button" onClick={() => alert('Open Friends page (not implemented)')}>View All <FaAngleRight /></button>
      </div>

      <div className="activity-tabs">
        <button className={tab === 'activities' ? 'active' : ''} onClick={() => setTab('activities')}>Activities</button>
        <button className={tab === 'online' ? 'active' : ''} onClick={() => setTab('online')}>Online</button>
      </div>

      <ul>
        {friends.map((friend, index) => (
          <li key={index} onClick={() => alert(`${friend.name}\nActivity: ${friend.activity}`)}>
            <img className="friend-image" src={friend.image} alt={friend.name} />
            <div className="friend-info">
              <span className="friend-name">{friend.name}</span>
              <span className="friend-activity">{friend.activity}</span>
              <span className="friend-time">{friend.time}</span>
            </div>
          </li>
        ))}
      </ul>

      <div className="fitness-progress">
        <h2>Progress</h2>
        <div className="progress-chart">
          {/* Simple legend — the chart is decorative here */}
          <ul className="progress-details">
            <li><span className="dot cardio-dot"></span>Cardio | 30 hrs</li>
            <li><span className="dot stretching-dot"></span>Stretching | 40 hrs</li>
            <li><span className="dot treadmill-dot"></span>Treadmill | 30 hrs</li>
            <li><span className="dot strength-dot"></span>Strength | 20 hrs</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default FriendsList;
