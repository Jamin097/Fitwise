import React, { useState } from 'react';
import './styles/Header.css';
import profilePic from './Assets/minnu.JPG';
import { FaSearch } from 'react-icons/fa';
import Profile from './Profile';

const Header = () => {
  const [showProfile, setShowProfile] = useState(false);

  return (
    <>
      <header className="header">
        <div className="header-content">
          <h1>Fitwise</h1>
          <div className="header-right">
            <div className="search-container">
              <input type="text" placeholder="Search" />
              <FaSearch className="search-icon" />
            </div>
            <div className="profile-pic" onClick={() => setShowProfile(true)}>
              <img src={profilePic} alt="Profile" />
            </div>
          </div>
        </div>
      </header>

      <Profile show={showProfile} onClose={() => setShowProfile(false)} />
    </>
  );
};

export default Header;
