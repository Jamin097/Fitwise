import React, { useState, useEffect } from 'react';
import './styles/Profile.css';

export default function Profile({ show, onClose }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    setUser(storedUser);
  }, []);

  if (!show || !user) return null;

  return (
    <div className="profile-overlay" onClick={onClose}>
      <div className="profile-card" onClick={e => e.stopPropagation()}>
        <h2>{user.username}'s Profile</h2>
        <ul>
          <li><strong>Email:</strong> {user.email}</li>
          <li><strong>Height:</strong> {user.height} cm</li>
          <li><strong>Weight:</strong> {user.weight} kg</li>
          <li><strong>Goal:</strong> {user.goal}</li>
          <li><strong>Injuries:</strong> {user.injuries || "None"}</li>
        </ul>
        <button onClick={onClose} className="close-btn">Close</button>
      </div>
    </div>
  );
}
