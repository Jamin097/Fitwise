// Overview.js - Improved interactivity version
import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler);

const Overview = () => {
  const [data, setData] = useState({
    labels: [],
    datasets: [
      {
        label: 'Steps',
        data: [],
        backgroundColor: 'rgba(106, 76, 147, 0.2)',
        borderColor: '#6a4c93',
        borderWidth: 2,
        pointBackgroundColor: '#ff6f61',
        pointHoverRadius: 8,
        pointRadius: 5,
        pointHoverBorderWidth: 3,
        fill: true,
        tension: 0.3,
      },
    ],
  });

  useEffect(() => {
    const historyRaw = localStorage.getItem('fit_history_v1');
    if (historyRaw) {
      try {
        const history = JSON.parse(historyRaw);
        setData({
          labels: history.labels,
          datasets: [{
            label: 'Steps',
            data: history.steps,
            backgroundColor: 'rgba(106, 76, 147, 0.2)',
            borderColor: '#6a4c93',
            borderWidth: 2,
            pointBackgroundColor: '#ff6f61',
            pointHoverRadius: 8,
            pointRadius: 5,
            pointHoverBorderWidth: 3,
            fill: true,
            tension: 0.3,
          }],
        });
        return;
      } catch (e) {}
    }

    // fallback demo data
    const demoLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];
    const demoSteps = [3000, 5000, 7000, 9000, 8000, 10000, 12000, 14000];
    setData({
      labels: demoLabels,
      datasets: [{
        label: 'Steps',
        data: demoSteps,
        backgroundColor: 'rgba(106, 76, 147, 0.2)',
        borderColor: '#6a4c93',
        borderWidth: 2,
        pointBackgroundColor: '#ff6f61',
        pointHoverRadius: 8,
        pointRadius: 5,
        pointHoverBorderWidth: 3,
        fill: true,
        tension: 0.3,
      }],
    });
  }, []);

  const options = {
    maintainAspectRatio: false,
    responsive: true,
    interaction: {
      mode: 'index',           // Shows tooltip for all points at the same x-index
      intersect: false,        // Tooltip shows even if not directly over point
      axis: 'x',
    },
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: 'rgba(30, 30, 50, 0.92)',
        titleColor: '#ff6f61',
        bodyColor: '#e0e0ff',
        borderColor: '#6a4c93',
        borderWidth: 1,
        cornerRadius: 8,
        padding: 12,
        displayColors: false,
        callbacks: {
          label: (context) => `${context.parsed.y.toLocaleString()} steps`,
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: { color: 'rgba(255, 255, 255, 0.08)' },
        ticks: { color: '#aaa' },
      },
      x: {
        grid: { color: 'rgba(255, 255, 255, 0.08)' },
        ticks: { color: '#aaa' },
      },
    },
    elements: {
      line: { tension: 0.3 },
    },
    hover: {
      mode: 'index',
      intersect: false,
    },
  };

  return (
    <div className="overview">
      <h2>Overview</h2>
      <div className="overview-content">
        <div className="stats">
          <div className="stat">
            <h3>Total Time</h3>
            <div className="progress-bar">
              <div className="progress" style={{ width: '75%' }}></div>
            </div>
            <div className="details">
              <span>748 Hr</span>
              <span>May</span>
            </div>
          </div>
          <div className="stat">
            <h3>Total Steps</h3>
            <div className="progress-bar">
              <div className="progress" style={{ width: '90%' }}></div>
            </div>
            <div className="details">
              <span>9,178 St</span>
              <span>May</span>
            </div>
          </div>
          <div className="stat">
            <h3>Target</h3>
            <div className="progress-bar">
              <div className="progress" style={{ width: '95%' }}></div>
            </div>
            <div className="details">
              <span>9,200 St</span>
              <span>May</span>
            </div>
          </div>
        </div>

        <div className="chart" style={{ minHeight: 300 }}>
          <Line data={data} options={options} />
        </div>
      </div>
    </div>
  );
};

export default Overview;